

dataset = 'isolet' % {'isolet','letters'}
load(['data/' dataset '_LMNN_V.mat']);

% INPUTS:
% [loaded data]
% xr - (d,n) training data
% yr - (1,n) training labels
% xe - (d,ne) test data
% ye - (1,ne) test labels
% L - (d,D) LMNN metric used to reduce dimensionality
% NOTE: data already multiplied by metric so we DO NOT multiply again
% i - random seed index
% BASELINE - 1 collect baseline information, 0 do not

% OUTPUTS:
% test_err - (1,ratios) the SNC test error for different compression ratios
% full_err - full kNN test error
% results - {1,ratios} results structure (contains learned inputs: V, corresponding labels: vy, initial sampled inputs: V0, learned gamma: gamma)
% baseline - {1,ratios} baseline information (knn err of initial sampled inputs: inits)

BASELINE = 0;

% number of random runs
runs = 1;
for i = 1:runs
   [test_err,full_err,results,baseline] = snc(xr,yr,xe,ye,i,BASELINE); 
   save(['results/' dataset '_run' num2str(i)],'test_err','full_err','results','baseline','-v7.3');
end



