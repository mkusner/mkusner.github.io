function [test_err,full_err,results,baseline] = snc(xr,yr,xe,ye,seed,BASELINE)
	% NOTE: dataset is usually preprocessed with LMNN! 
	% We reduced dimensionality with the following two rules:
	%   d >= 200            reduced to 100
	%   100 <= d < 200      reduced to 50
	% There are many datasets preprocessed with LMNN (datasets ending in: '_LMNN_V.mat') in data/
	% 
	% INPUTS:
	% xr - (d,n) training data
	% yr - (1,n) training labels
	% xe - (d,ne) test data
	% ye - (1,ne) test labels
	%
	% OUTPUTS:
	% test_err - (1,ratios) test error of SNC for different compression ratios
	% full_err - error of knn on full training set
	% results - {1,ratios} compression results for each ratio
	% baseline - {1,ratios} baseline information for each ratio

	addpath(genpath('mLMNN2.4'));
        addpath('util');

	% remove repeats
	xr = xr';
	xe = xe';
	[xr,rix] = unique(xr,'rows','first');
	[xe,eix] = unique(xe,'rows','first');
	yr = yr(rix);
	ye = ye(eix);
	xr = xr';
	xe = xe';
	[d,n]  = size(xr);
	[~,ne] = size(xe);
	
	% compression ratios
	percents = [0.01,0.02,0.04,0.08,0.16];
	range = floor(percents.*n)
	
	func = 'solve_sI';
	cknn_func = 'cknn';
	compress_maxiter = 100
	metric_maxiter = 10;
	k = 1;
        
	[results,baseline] = compress(k,xr,xe,yr,ye,range,func,cknn_func,compress_maxiter,metric_maxiter,seed,BASELINE);
        
	% compute test error
	for i = 1:length(range)
		V = results.V{i};
		vy = results.vy{i};
		gamma = results.gamma(i);
		A = gamma*eye(d);
		test_err(i) = knnclassifytreeomp(A,double(V),vy,double(xe),ye,k,'train',0);
	end

	full_err = knnclassifytreeomp([],double(xr),yr,double(xe),ye,k,'train',0); 

end






