function [obj,gr]=solve_sI(s,V,vy,X,y);
% compute objective and gradient w/r/t scale s

[d,n]=size(X);
m=length(vy);
M = s*eye(d);

Xs = M*X;
Vs = M*V;

% compute matrices
K=exp(-distance(Xs,Vs));
Z=sum(K,2);
P=bsxfun(@times,K,1./Z);
% http://blog.smola.org/post/987977550/log-probabilities-semirings-and-floating-point-numbers
logP = log(P);

% Compute p (probability of input i to be classified with label y(i))
p=zeros(n,1);
p2=zeros(n,1);
un=unique(y);
for i=1:length(un)
	jj=find(vy==un(i));
	ii=find( y==un(i));

	% for each i find max
	pis = max(logP(ii,:),[],2); 
	
	% for each i compute log of sum of exponents
	log_plus = pis + log(sum(exp(bsxfun(@minus, logP(ii,jj), pis)),2));
	p(ii)=exp(log_plus);
end;


obj=-sum(log(p));
Q0=double(repmat(y',1,m)==repmat(vy,n,1)); 
Q=bsxfun(@minus,Q0,p);
inv_p = 1.0./p;
T = -(Q.*P);
pisI=loss_1NN_sI_log(X,V,T',s,inv_p);
gr = -2*pisI;

