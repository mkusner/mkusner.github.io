function [results,baseline] = compress(k,xr,xe,yr,ye,range,func,cknn_func,compress_maxiter,metric_maxiter,seed,BASELINE)
	% xr - (d,n)
	% xe - (d,ne)
	% yr - (1,n)
	% ye - (1,ne)

	[d,n]=size(xr);

	results = {};
	results.errs=[];
	results.terrs=[];
	results.V = {};
	results.vy = {};
	results.V0 = {};
	results.gamma = [];

	baseline = {};
	baseline.inits=[];

	gammas = 2.^[-6,-4,-2,0,2,4,6];

	objective = [];
	Vs = {};
	As = {};

	for c=1:length(range)
		m=range(c);
		
		% select initial compressed inputs
		[V0,vy,II] = initialize(xr,yr,m,k,seed);
		V = V0;
		
		% initialize gamma
		%gamma = 1;
		
		% alternate once
		%[gamma,objgamma]=minimize(gamma(:),func,metric_maxiter,V,vy,xr,yr);
		
		for g = 1:length(gammas)
		
			A = gammas(g)*eye(d); 
			[V,objV]=minimize(V(:),cknn_func,compress_maxiter,vy,xr,yr,A);
			V = reshape(V,[d,m]);
			
			% use train error to select gamma
			objective(g) = knnclassifytreeomp(A,double(V),vy,double(xr),yr,k,'train',0);
			Vs{g} = V;
			As{g} = A;
		end
		
		[~,gix] = min(objective);
		
		V = Vs{gix};
		A = As{gix};
		
		% store knn sampling baseline results
		if BASELINE
		    baseline.inits(c)=knnclassifytreeomp([],double(V0),vy,double(xe),ye,k,'train',0);
		end
		
		% store results        
		results.V{c} = V;
		results.vy{c} = vy;
		results.V0{c} = V0;
		results.gamma(c) = gammas(gix);
		
		% compute test error
		results.train_err(c)=knnclassifytreeomp(A,double(V),vy,double(xr),yr,k,'train',0)
	end
end
