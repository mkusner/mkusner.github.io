function [obj,gr]=cknn(V,vy,X,y,M);
% compute objective and gradient w/r/t compressed inputs V


% reshape input
[d,n]=size(X);
m=length(vy);
V=reshape(V,[d,m]);

XM = M*X;
VM = M*V;

K=exp(-distance(XM,VM)*0.5);
Z=sum(K,2);
P=bsxfun(@times,K,1./Z);

% http://blog.smola.org/post/987977550/log-probabilities-semirings-and-floating-point-numbers
logP = log(P);

% Compute p (probability of input i to be classified with label y(i))
p=zeros(n,1);
un=unique(y);
for i=1:length(un)
	jj=find(vy==un(i));
	ii=find( y==un(i));
	
	% for each i find max
	pis = max(logP(ii,:),[],2); 
	
	% for each i compute log of sum of exponents
	log_plus = pis + log(sum(exp(bsxfun(@minus, logP(ii,jj), pis)),2));
	p(ii)=exp(log_plus);
end;



obj=-sum(log(p));
Q0=double(repmat(y',1,m)==repmat(vy,n,1)); 
Q=bsxfun(@minus,Q0,p);
inv_p = 1.0./p;
POP = bsxfun(@times,P,inv_p);

gr=-X*(Q.*POP)+bsxfun(@times,V,sum(Q.*POP,1));
gr=(M'*M)*gr;
gr=gr(:);
