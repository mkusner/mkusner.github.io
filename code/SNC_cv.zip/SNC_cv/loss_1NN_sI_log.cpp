#if !defined(_WIN32)
#define dgemm dgemm_
#endif

#include "string.h"
#include <omp.h>
#include "mex.h"
#include "blas.h"
#include "lapack.h"
#include <math.h>
/*
 * X  - (d,n)
 * V  - (d,m)
 * T  - (m,n)
 * s  - (1,1)
 */

#include <iostream>

using namespace std;

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

	// input
	double* X = mxGetPr(prhs[0]);
	double* V = mxGetPr(prhs[1]);

	double* T = mxGetPr(prhs[2]);
	double  s = (double)(*(mxGetPr(prhs[3])));
	double* inv_p = mxGetPr(prhs[4]);
 
	long n = (long)(mxGetN(prhs[0]));
	long m = (long)(mxGetN(prhs[1]));
	long d = (long)(mxGetM(prhs[0]));
	// output
	plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
	double* pisI = mxGetPr(plhs[0]);
	pisI[0] = 0;
	// lapack variables
	/*long   one     = 1;
	long   dp1      = d+1;
	double zero    = 0.0;
	double plusone = 1.0;
	double minusone = -1.0;
	char T = 'T';
	char N = 'N';*/

	double  temp = 0.0;
	
	int i,k,a;
	double sum = 0.0;
	//#pragma omp parallel for shared(P, y, vy) private(count) reduction(+: sum)
	#pragma omp parallel for default(shared) reduction(+: sum)
	for(i = 0; i < n; i++) {
		for(k = 0; k < m; k++) {
			for(a = 0; a < d; a++) {
				sum += inv_p[i]*pow(X[a + d*i]-V[a + d*k],2.0)*T[k + i*m];
			}		
		}
	}

	
	pisI[0] = sum*s;
}

