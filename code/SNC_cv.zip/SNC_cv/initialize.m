function [V0,vy,II]=initialize(xr,yr,m,k,seed)

    rng(seed,'twister');

    [d,n]=size(xr);
    
    un = unique(yr);
    C  = length(un);
    ratios = zeros(1,C);
    for i = 1:C
    	ratios(i) = sum(yr == un(i));
    end
    ratios = ratios ./ sum(ratios);
    
    counts = round(ratios*m);


    i=[];
    for cc = 1:C
        if counts(cc)
            i = [i, randsample(find(yr == un(cc)),counts(cc))];
        end
    end
    rest = m-length(i);
    samps = randsample(C,rest);
    for rr = 1:rest
        i = [i, randsample(find(yr == un(samps(rr))),1)];
    end
    
    V0=xr(:,i(1:m));
    vy=yr(i(1:m));
    II=i;

end
