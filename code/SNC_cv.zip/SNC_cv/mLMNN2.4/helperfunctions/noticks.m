set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'ZTick',[]);
